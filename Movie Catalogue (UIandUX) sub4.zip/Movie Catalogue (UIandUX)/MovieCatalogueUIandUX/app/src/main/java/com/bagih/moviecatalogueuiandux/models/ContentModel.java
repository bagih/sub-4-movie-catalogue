package com.bagih.moviecatalogueuiandux.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.SerializedName;

@Entity(tableName = "content", indices = @Index(value = {"title"}, unique = true))
public class ContentModel implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    private int uid;
    @SerializedName(value = "title", alternate = {"name"})
    private String title;
    @SerializedName("overview")
    private String description;
    @SerializedName("poster_path")
    private String imgPoster;
    private int contentType;

    public ContentModel(){

    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getContentType() {
        return contentType;
    }

    public void setContentType(int contentType) {
        this.contentType = contentType;
    }

    protected ContentModel(Parcel in) {
        title = in.readString();
        description = in.readString();
        imgPoster = in.readString();
        uid = in.readInt();
        contentType = in.readInt();
    }

    public static final Creator<ContentModel> CREATOR = new Creator<ContentModel>() {
        @Override
        public ContentModel createFromParcel(Parcel in) {
            return new ContentModel(in);
        }

        @Override
        public ContentModel[] newArray(int size) {
            return new ContentModel[size];
        }
    };

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImgPoster() {
        return imgPoster;
    }

    public void setImgPoster(String imgPoster) {
        this.imgPoster = imgPoster;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(imgPoster);
        dest.writeInt(this.contentType);
        dest.writeInt(this.uid);
    }
}
