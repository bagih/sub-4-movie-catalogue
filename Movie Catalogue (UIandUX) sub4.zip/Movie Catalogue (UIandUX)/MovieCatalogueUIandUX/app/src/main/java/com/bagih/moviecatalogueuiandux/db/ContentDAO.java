package com.bagih.moviecatalogueuiandux.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.bagih.moviecatalogueuiandux.models.ContentModel;

import java.util.List;


@Dao
public interface ContentDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(ContentModel... contentModels);

    @Query("DELETE FROM content WHERE uid = :uid")
    void deleteById(int uid);

    @Query("SELECT COUNT(uid) FROM content WHERE title = :title")
    int getContentByTitle(String title);

    @Query("SELECT * FROM content WHERE contentType = :contentType")
    List<ContentModel> getContentsByContentType(int contentType);
}
