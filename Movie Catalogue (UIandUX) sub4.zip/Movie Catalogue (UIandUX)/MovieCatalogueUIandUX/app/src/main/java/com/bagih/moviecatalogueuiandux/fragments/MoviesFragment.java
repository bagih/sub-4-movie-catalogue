package com.bagih.moviecatalogueuiandux.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bagih.moviecatalogueuiandux.adapters.ContentAdapter;
import com.bagih.moviecatalogueuiandux.models.ContentModel;
import com.bagih.moviecatalogueuiandux.MainViewModel;
import com.bagih.moviecatalogueuiandux.R;

import java.util.ArrayList;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */
public class MoviesFragment extends Fragment {
    private ContentAdapter adapter;
    private ProgressBar progressBar;

    public MoviesFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movies,container,false);
        RecyclerView rvMovie = view.findViewById(R.id.rv_movies);
        rvMovie.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new ContentAdapter(getActivity());
        rvMovie.setAdapter(adapter);

        MainViewModel mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        mainViewModel.setContents("movie");
        mainViewModel.getContents().observe(this, getContents);

        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_movie);
        //tambahkan loading nanti
        progressBar.setVisibility(View.VISIBLE);
        return view;
    }

    private Observer<ArrayList<ContentModel>> getContents = new Observer<ArrayList<ContentModel>>() {
        @Override
        public void onChanged(ArrayList<ContentModel> contentModels) {
            if(contentModels != null){
                progressBar = (ProgressBar) Objects.requireNonNull(getView()).findViewById(R.id.progress_bar_movie);
                //hilangkan loading nanti
                progressBar.setVisibility(View.INVISIBLE);
                adapter.setmContentModel(contentModels);
            }
        }
    };
}
