package com.bagih.moviecatalogueuiandux.fragments;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bagih.moviecatalogueuiandux.adapters.ContentAdapter;
import com.bagih.moviecatalogueuiandux.models.ContentModel;
import com.bagih.moviecatalogueuiandux.MainViewModel;
import com.bagih.moviecatalogueuiandux.R;

import java.util.ArrayList;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */
public class TvFragment extends Fragment {

    public ContentAdapter adapter;
    private ProgressBar progressBar;

    public TvFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tv,container,false);
        RecyclerView rvTv = view.findViewById(R.id.rv_tv);
        rvTv.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new ContentAdapter(getActivity());
        rvTv.setAdapter(adapter);

        MainViewModel mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        mainViewModel.setContents("tv");
        mainViewModel.getContents().observe(this, getContents);

        progressBar = (ProgressBar) view.findViewById(R.id.progress_bar_tv);
        //tambahkan loading nanti
        progressBar.setVisibility(View.VISIBLE);

        return view;
    }

    private Observer<ArrayList<ContentModel>> getContents = new Observer<ArrayList<ContentModel>>() {
        @Override
        public void onChanged(ArrayList<ContentModel> contentModels) {
            if(contentModels != null){
                progressBar = (ProgressBar) Objects.requireNonNull(getView()).findViewById(R.id.progress_bar_tv);
                //hilangkan loading nanti
                progressBar.setVisibility(View.INVISIBLE);
                adapter.setmContentModel(contentModels);
            }
        }
    };
}
