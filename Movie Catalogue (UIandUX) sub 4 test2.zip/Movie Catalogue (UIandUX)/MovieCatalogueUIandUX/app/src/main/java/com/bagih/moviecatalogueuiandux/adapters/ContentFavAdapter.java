package com.bagih.moviecatalogueuiandux.adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.bagih.moviecatalogueuiandux.R;
import com.bagih.moviecatalogueuiandux.db.ContentDAO;
import com.bagih.moviecatalogueuiandux.db.ContentDatabase;
import com.bagih.moviecatalogueuiandux.models.ContentModel;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

public class ContentFavAdapter extends RecyclerView.Adapter<ContentFavAdapter.ContentFavViewHolder> {

    private Context context;
    private List<ContentModel> contentModels = new ArrayList<>();
    private ImageView imgPoster;
    private TextView title;
    private TextView description;
    private Button btnDelete;

    public ContentFavAdapter(Context context){
        this.context = context;
    }

    public void setContents(List<ContentModel> contentModels){
        this.contentModels = contentModels;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ContentFavViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_row_fav, parent, false);
        return new ContentFavAdapter.ContentFavViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContentFavViewHolder holder, int position) {
        holder.bind(contentModels.get(position));
    }

    @Override
    public int getItemCount() {
        return contentModels.size();
    }

    public class ContentFavViewHolder extends RecyclerView.ViewHolder {

        public ContentFavViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPoster = itemView.findViewById(R.id.img_photo_item_fav);
            title = itemView.findViewById(R.id.tv_item_name_fav);
            description = itemView.findViewById(R.id.tv_item_description_fav);
            btnDelete = itemView.findViewById(R.id.btn_delete_fav);
        }

        public void bind(final ContentModel contentModel) {
            String imgUrl = "https://image.tmdb.org/t/p/w185";
            Glide.with(context)
                    .load(imgUrl + contentModel.getImgPoster())
                    .apply(new RequestOptions().override(55, 55))
                    .into(imgPoster);
            title.setText(contentModel.getTitle());
            description.setText(contentModel.getDescription());
            btnDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getContext());
                    builder.setTitle(R.string.confirm_title);
                    builder.setMessage(R.string.confirm_message);
                    builder.setCancelable(false);
                    builder.setPositiveButton(R.string.yes_confirm, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ContentDAO contentDAO = Room.databaseBuilder(itemView.getContext(), ContentDatabase.class, "db_content")
                                    .allowMainThreadQueries()
                                    .build()
                                    .getContentDAO();

                            contentDAO.deleteById(contentModels.get(getAdapterPosition()).getUid());
                            contentModels.remove(contentModel);
                            notifyDataSetChanged();
                            Toast.makeText(context, R.string.success_info, Toast.LENGTH_SHORT).show();

                        }
                    });

                    builder.setNegativeButton(R.string.no_confirm, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            builder.setCancelable(true);
                        }
                    });
                    builder.show();
                }
            });
        }
    }
}
