package com.bagih.moviecatalogueuiandux.api;

import com.bagih.moviecatalogueuiandux.models.ContentResponseModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiEndpoints {
    @GET("discover/{type}")
    Call<ContentResponseModel> getContents(@Path("type") String contentType);
}
