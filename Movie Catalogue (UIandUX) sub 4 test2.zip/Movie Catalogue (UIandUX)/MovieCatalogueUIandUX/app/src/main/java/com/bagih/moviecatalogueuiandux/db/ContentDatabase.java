package com.bagih.moviecatalogueuiandux.db;


import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.bagih.moviecatalogueuiandux.models.ContentModel;

@Database(entities = {ContentModel.class}, version = 1, exportSchema = false)
public abstract class ContentDatabase extends RoomDatabase {
    public abstract ContentDAO getContentDAO();
}
