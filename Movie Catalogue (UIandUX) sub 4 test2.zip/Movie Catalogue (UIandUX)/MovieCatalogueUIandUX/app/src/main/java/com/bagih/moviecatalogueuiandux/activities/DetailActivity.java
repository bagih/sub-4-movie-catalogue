package com.bagih.moviecatalogueuiandux.activities;


import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.bagih.moviecatalogueuiandux.R;
import com.bagih.moviecatalogueuiandux.db.ContentDAO;
import com.bagih.moviecatalogueuiandux.db.ContentDatabase;
import com.bagih.moviecatalogueuiandux.models.ContentModel;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class DetailActivity extends AppCompatActivity {
    private ProgressBar progressBar;
    ContentModel contentModel;
    ContentDAO contentDAO;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        progressBar = (ProgressBar) findViewById(R.id.progress_bar_detail);
        progressBar.setVisibility(View.VISIBLE);
        Intent intent = getIntent();
        contentModel = intent.getParcelableExtra("content");
        if (contentModel != null){
            progressBar.setVisibility(View.INVISIBLE);
            showBodyDetails(contentModel);
            contentDAO = Room.databaseBuilder(this, ContentDatabase.class, String.valueOf(R.string.db_name))
                    .allowMainThreadQueries()
                    .build()
                    .getContentDAO();
            }

        }

        private void showBodyDetails(ContentModel contentModel){
            String imgUrl = "https://image.tmdb.org/t/p/w185";
            TextView title = findViewById(R.id.tv_detail);
            TextView description = findViewById(R.id.tv_desc_detail);
            ImageView imgPoster = findViewById(R.id.imageview_detail);

            title.setText(contentModel.getTitle());
            description.setText(contentModel.getDescription());
            Glide.with(this)
                    .load(imgUrl+contentModel.getImgPoster())
                    .apply(new RequestOptions().override(166,260))
                    .into(imgPoster);
        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail_activity_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_add_favorite:
                try{
                    if(contentDAO.getContentByTitle(contentModel.getTitle()) > 0){
                        item.setEnabled(false);
                    } else {
                        contentDAO.insert(contentModel);
                        setResult(RESULT_OK);
                        Toast.makeText(this, R.string.success_insert_favorite, Toast.LENGTH_SHORT).show();
                    }
                } catch (SQLiteConstraintException e){
                    Toast.makeText(this, e.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                }

        }
        return true;
    }
}
