package com.bagih.moviecatalogueuiandux.fragments;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bagih.moviecatalogueuiandux.MainViewModel;
import com.bagih.moviecatalogueuiandux.R;
import com.bagih.moviecatalogueuiandux.adapters.ContentFavAdapter;
import com.bagih.moviecatalogueuiandux.db.ContentDAO;
import com.bagih.moviecatalogueuiandux.db.ContentDatabase;
import com.bagih.moviecatalogueuiandux.models.ContentModel;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class FavTvFragment extends Fragment {
    private ContentFavAdapter adapter;


    public FavTvFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_fav_tv, container, false);
        RecyclerView rvMovie = view.findViewById(R.id.rv_tv_fav);
        rvMovie.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new ContentFavAdapter(getActivity());
        rvMovie.setAdapter(adapter);

        ArrayList<ContentModel> data = (ArrayList<ContentModel>) loadFavContents();

        MainViewModel mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        mainViewModel.setFavContent(data);
        mainViewModel.getContents().observe(this, getContents);

        return view;
    }

    private List<ContentModel> loadFavContents(){
        ContentDatabase database = Room.databaseBuilder(getActivity(), ContentDatabase.class, String.valueOf(R.string.db_name))
                .allowMainThreadQueries()
                .build();
        ContentDAO contentDAO = database.getContentDAO();
        return contentDAO.getContentsByContentType(2);
    }

    Observer<ArrayList<ContentModel>> getContents = new Observer<ArrayList<ContentModel>>() {
        @Override
        public void onChanged(ArrayList<ContentModel> contentModels) {
            if(contentModels != null){
                adapter.setContents(contentModels);
            }
        }
    };}
