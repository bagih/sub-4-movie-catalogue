package com.bagih.moviecatalogueuiandux.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.bagih.moviecatalogueuiandux.R;
import com.bagih.moviecatalogueuiandux.adapters.FavoriteSectionPagerAdapter;
import com.bagih.moviecatalogueuiandux.adapters.SectionsPagerAdapter;
import com.google.android.material.tabs.TabLayout;

public class FavoriteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);

        FavoriteSectionPagerAdapter favoriteSectionPagerAdapter = new FavoriteSectionPagerAdapter(this, getSupportFragmentManager());
        ViewPager viewPager = findViewById(R.id.view_pager_main_fav);
        viewPager.setAdapter(favoriteSectionPagerAdapter);
        TabLayout tabs = findViewById(R.id.tabs_main_fav);
        tabs.setupWithViewPager(viewPager);

        getSupportActionBar().setElevation(0);
    }
}
