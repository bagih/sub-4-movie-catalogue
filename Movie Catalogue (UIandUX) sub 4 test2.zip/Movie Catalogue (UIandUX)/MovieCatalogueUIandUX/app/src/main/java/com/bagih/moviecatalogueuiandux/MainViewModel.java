package com.bagih.moviecatalogueuiandux;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.bagih.moviecatalogueuiandux.activities.MainActivity;
import com.bagih.moviecatalogueuiandux.api.ApiClient;
import com.bagih.moviecatalogueuiandux.api.ApiEndpoints;
import com.bagih.moviecatalogueuiandux.models.ContentModel;
import com.bagih.moviecatalogueuiandux.models.ContentResponseModel;

import java.util.ArrayList;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainViewModel extends ViewModel {

    private MutableLiveData<ArrayList<ContentModel>> contentList = new MutableLiveData<>();

    public void setContents(final String contentType){
        ApiEndpoints apiEndpoints = ApiClient.getClient().create(ApiEndpoints.class);
        Call<ContentResponseModel> call = apiEndpoints.getContents(contentType);
        call.enqueue(new Callback<ContentResponseModel>() {
            @Override
            public void onResponse(Call<ContentResponseModel> call, Response<ContentResponseModel> response) {
                try{
                    ArrayList<ContentModel> contentModels = response.body().getResults();
                    for (ContentModel data : contentModels){
                        data.setContentType(contentType.equals("movie") ? 1 : 2);
                    }
                    contentList.postValue(contentModels);
                } catch (Exception e){
                    Log.d(MainActivity.class.getSimpleName(), Objects.requireNonNull(e.getLocalizedMessage()));
                }
            }

            @Override
            public void onFailure(Call<ContentResponseModel> call, Throwable t) {
                Log.d(MainActivity.class.getSimpleName(), Objects.requireNonNull(t.getLocalizedMessage()));
            }
        });
    }

    public void setFavContent(ArrayList<ContentModel> contentModels){
        contentList.postValue(contentModels);
    }

    public LiveData<ArrayList<ContentModel>> getContents(){
        return contentList;
    }
}
